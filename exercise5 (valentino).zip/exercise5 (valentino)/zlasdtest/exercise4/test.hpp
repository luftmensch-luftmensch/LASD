
#ifndef EX4TEST_HPP
#define EX4TEST_HPP

/* ************************************************************************** */

void testSimpleExercise4();

void testFullExercise4();

/* ************************************************************************** */

#endif
